using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EZCameraShake;

public class obstacle : MonoBehaviour
{
    public int damage = 1;
    public float speed = 1f;
    public GameObject effect;
    public Animator camanim;
    public GameObject audioSource;

    private void Update()
    {
        transform.Translate(Vector2.down * speed * Time.deltaTime);
    }
   
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Instantiate(effect, transform.position, Quaternion.identity);
            Instantiate(audioSource, transform.position, Quaternion.identity);
            collision.GetComponent < player > ().health -= damage;
            Destroy(gameObject);
            CameraShaker.Instance.ShakeOnce(3f, 2f, .1f, 1f);

        }
    }

}
