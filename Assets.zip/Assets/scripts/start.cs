using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class start : MonoBehaviour
{
 
   public  void QuitG()
    {
        Application.Quit();
        Debug.Log("QUIT");
    }
    void Update()
    {
        
    }
    public void StartGame()
    {
        SceneManager.LoadScene("level");
    }
}
