using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Gamepause : MonoBehaviour
{
    [SerializeField] GameObject pauseMENU;

    public void Gpause()
    {

        pauseMENU.SetActive(true);
        Time.timeScale = 0f;
    }
    public void Gresume()
    {
        pauseMENU.SetActive(false);
        Time.timeScale = 1f;
    }
    public void Ghome()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("start");
    }
}
