using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class end : MonoBehaviour
{
    public Text SCORE;
    void Start()
    {
        SCORE.text = PlayerPrefs.GetInt("SCORE").ToString("0");

    }
    public void Restart()
    {
        SceneManager.LoadScene("level");
    }
    public void ManinMneu()
    {
        SceneManager.LoadScene("start");
    }
}
