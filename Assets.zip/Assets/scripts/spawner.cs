using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner : MonoBehaviour
{
    public Transform[] spwanpoints;
    public GameObject obs;
    private float timeBetweenSpawn;
    public float startTimeBtwSpawn;
    public float decreaseTime;
    public float mintime = 0.65f;
    
    void Update(){
        if (timeBetweenSpawn <= 0)
        {
            randspawn();
            timeBetweenSpawn = startTimeBtwSpawn;
            if (startTimeBtwSpawn > mintime)
            {
                startTimeBtwSpawn -= decreaseTime;
            }
        }
        else
        {
            timeBetweenSpawn -= Time.deltaTime;
        }
    }


    void randspawn()
    {
        int randI = Random.Range(0, spwanpoints.Length);
        for (int i = 0; i < spwanpoints.Length; i++)
        {
            if (randI != i)
            {
                Instantiate(obs, spwanpoints[i].position, Quaternion.identity);
            }
        }
    }
}
