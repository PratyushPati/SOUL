using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityStandardAssets.CrossPlatformInput;

public class player : MonoBehaviour
{
    public float speed=15f;
    private Rigidbody2D rb;
    public float width = 5f;
    public float sideforce = 2f;
    public int health = 3;
    public GameObject effect;
    public GameObject gameO;
    public Text healthDispaly;
    public Image first;
    public Image second;
    public Image third;
    public float rdelay = 1.0f;
    public score score; 

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
   
    void FixedUpdate()
    {
        if (health == 3)
        {
            first.enabled = true;
            second.enabled = true;
            third.enabled = true;
        }
        if (health == 2)
        {
            first.enabled = true;
            second.enabled = true;
            third.enabled = false;
        }
        if (health == 1)
        {
            first.enabled = true;
            second.enabled = false;
            third.enabled = false;
        }
        if (health == 0)
        {
            first.enabled = false;
            second.enabled = false;
            third.enabled = false;
        }
        if (health <= 0)  {
            Instantiate(effect, transform.position, Quaternion.identity);
            Destroy(gameObject);
            score.Gend();
        }
        float x = CrossPlatformInputManager.GetAxis("Horizontal")*Time.deltaTime*speed;
        Vector2 newpos = rb.position + Vector2.right * x;
        newpos.x = Mathf.Clamp(newpos.x, -width, width);

        rb.MovePosition(newpos);
    }
}
