using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class score : MonoBehaviour
{
    public int scoref;
    public Text scoreD;

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Obstacle"))
        {
            scoref++;
        }
        PlayerPrefs.SetInt("SCORE", scoref);
    }
    private void Update()
    {
        scoreD.text =scoref.ToString();
    }
    public void Gend()
    {
        Invoke(nameof(endGame), 1.0f);
    }
    public void endGame()
    {
        SceneManager.LoadScene("end");
    }
}
